<?php
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(569, 0, 'pp_skin', 'transparent', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(571, 0, 'pp_display_full_desc', 'true', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(572, 0, 'pp_h1_size', '40', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(573, 0, 'pp_h2_size', '32', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(574, 0, 'pp_h3_size', '26', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(575, 0, 'pp_h4_size', '24', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(576, 0, 'pp_h5_size', '22', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(577, 0, 'pp_h6_size', '18', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(578, 0, 'pp_button_bg_color', '#fe7301', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(579, 0, 'pp_button_font_color', '#ffffff', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(580, 0, 'pp_button_border_color', '#e56801', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(581, 0, 'pp_homepage_style', 'slideshow', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(583, 0, 'pp_slider_timer', '5', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(584, 0, 'pp_homepage_slideshow_trans', '1', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(585, 0, 'pp_homepage_title', 'Simply Delicious', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(589, 0, 'pp_blog_slideshow', 'true', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(591, 0, 'pp_blog_slider_timer', '5', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(592, 0, 'pp_blog_slideshow_trans', '1', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(593, 0, 'pp_blog_display_full', 'true', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(595, 0, 'pp_contact_display_map', 'true', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(596, 0, 'pp_contact_lat', '13.740052', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(597, 0, 'pp_contact_long', '100.474777', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(598, 0, 'pp_contact_map_zoom', '15', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(599, 0, 'pp_contact_info_box', 'Pluto Restaurant Mars Avenue.', 'yes');");

?>